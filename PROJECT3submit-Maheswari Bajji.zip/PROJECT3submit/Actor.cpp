#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"
#include <cstdlib>
#include <stdlib.h>     /* srand, rand */


//my base class constructor
Actor::Actor(StudentWorld* sw, int image_id, int x, int y, int depth, int direction)
    : GraphObject(image_id, x, y, direction, depth, 1), m_world(sw)
{
    isActive = true;

};
//Actor constructor creates Graph World object 
MovingActor::MovingActor(StudentWorld* sw, int image_id, int x, int y, int depth, int direction)
    : Actor(sw, image_id, x, y, depth, direction), m_world(sw)
{
    isActive = true;
}

//returns the world the actor is in
/*
StudentWorld* Actor::getWorld() {
    return m_world;
}
*/

//used to move PYB by 2 pixels each tick 
void MovingActor::movePYB() {


    //gotCoin = false;
    //get where I am standing on
    int currentX = getX();
    int currentY = getY();

    Board::GridEntry toLeft, toRight, toUp, toDown;
    //if I am in the middle of the coin square(same X and Y) 
    if (currentX % 16 == 0 && currentY % 16 == 0)
    {
        //get the contents of board next to me 
        m_world->boardThingNextToMe(currentX, currentY, toRight, toUp, toLeft, toDown);

        //move right
        if (directionOfWalk == right)
        {
            //if I can move right (meaning there is a actor to my right and its not empty then move)
            if (toRight != Board::empty) {
                moveMe(right, true);
            }
            //if I cannot move to the right change my walk direction to one thats perpendicular 
            else
            {
                if (toUp != Board::empty) {

                    directionOfWalk = up;
                }
                else if (toDown != Board::empty)
                {

                    directionOfWalk = down;
                }
            }

        }

        //moving up
        if (directionOfWalk == up)
        {
            //if I can move up move up else change to perpendicular direction
            if (toUp != Board::empty) {
                moveMe(up, true);
            }
            else
            {
                if (toRight != Board::empty) {

                    directionOfWalk = right;
                }
                else if (toLeft != Board::empty)
                {

                    directionOfWalk = left;
                }
            }

        }

        //moving left
        //if I can move left move left else change to perpendicular direction

        if (directionOfWalk == left)
        {
            if (toLeft != Board::empty) {
                moveMe(left, true);
            }
            else
            {
                if (toUp != Board::empty) {

                    directionOfWalk = up;
                }
                else if (toDown != Board::empty)
                {

                    directionOfWalk = down;
                }
            }

        }

        //moving down
        //if I can move down move down else change to perpendicular direction

        if (directionOfWalk == down)
        {

            // setDirection(right);

            if (toDown != Board::empty) {
                moveMe(down, true);

            }
            else
            {
                if (toRight != Board::empty) {
                    directionOfWalk = right;
                }
                else if (toLeft != Board::empty)
                {
                    directionOfWalk = left;
                }
            }

        }

    }
    //if I am not in the middle of a blue square just move forward
    else
    {
        if (directionOfWalk == right)
        {
            moveMe(right, false);
        }
        if (directionOfWalk == up)
        {
            moveMe(up, false);
        }
        if (directionOfWalk == left)
        {
            moveMe(left, false);
        }
        if (directionOfWalk == down)
        {
            moveMe(down, false);
        }



    }
}

//moves PYB to a given loc *used in teleport*
void MovingActor::moveMe(int direction, bool canChangeDieRoll) {
    if (direction == 180) {
        setDirection(left);
    }
    else
        setDirection(right);
    moveAtAngle(direction, 2);
    ticks_to_move--;
    //if you are at the block's middle change roll of dice by one (used for printing die roll to screen)
    if (canChangeDieRoll) {
        die_roll--;
        if (die_roll <= 0) {
            die_roll = 0;
        }
    }

    //if you should no longer move froward stay still by changing isInWaitingToRollState to true
    if (ticks_to_move <= 0) {
        isInWaitingToRollState = true;
    }
}



//constructor of the player avatar (sets walk direction, waiting to roll state and everything else)
PlayerAvatar::PlayerAvatar(StudentWorld* sw, int id, int x, int y, int whichPlayer) :
    MovingActor(sw, id, x, y, 0, 0)
{
    setDirection(0);
    //isInWaitingToRollState = true;
    setWaitingToRollState(true);
    playerNum = whichPlayer;
    setTicksToMove(0);
    //ticks_to_move = 0;
    setDirectionOfWalk(right);
    //directionOfWalk = right;
    setRoll(0);
    //die_roll = 0;
    //sw->playSound(SOUND_GIVE_COIN);
    coins = 0;
    gotCoin = false;
    stars = 0;
    canGetStar = true;
    hasBeenAttacked = false;
}

//used to swap twp players
void PlayerAvatar::swapMeWith(PlayerAvatar* other) {
    int tempX = getX(), tempY = getY(), tempTicks = getTicksToMove(), tempWalkDirection = getDirectionOfWalk(), tempFaceDirection = getDirection();
    bool tempisWaitingToRoll = isWaitingToRoll();

    //face of player
    setDirection(other->getDirection());
    //pause values 
    setWaitingToRollState(other->isWaitingToRoll());
    //walk direction
    setDirectionOfWalk(other->getDirectionOfWalk());
    //swap ticks
    setTicksToMove(other->getTicksToMove());
    //swap x and y 
    moveTo(other->getX(), other->getY());

    //wasTeleported = true; 
    //face
    other->setDirection(tempFaceDirection);
    //pause
    other->setWaitingToRollState(tempisWaitingToRoll);
    //walk direction
    other->setDirectionOfWalk(tempWalkDirection);
    //swap ticks
    other->setTicksToMove(tempTicks);
    //swap x and y 
    other->moveTo(tempX, tempY);
    //other->updateTeleport(true);

}

//function that returns whether 3 or more directions are surrounding me 
bool MovingActor::isAtFork() {
    //peach 

    //not in middle of swuare then return false 
    if (getX() % SPRITE_WIDTH != 0 || getY() % SPRITE_HEIGHT != 0) {
        return false;
    }
    //find out how many open directions there are 
    Board::GridEntry toRight, toUp, toLeft, toDown;
    getWorld()->boardThingNextToMe(getX(), getY(), toRight, toUp, toLeft, toDown);
    // int walkDir;

     //find out how many directions are open for the player to chose from 
    int numberOfOpenDirections = 0;
    if (toRight)
        numberOfOpenDirections++;
    if (toLeft)
        numberOfOpenDirections++;
    if (toUp)
        numberOfOpenDirections++;
    if (toDown)
        numberOfOpenDirections++;
    //cerr << "there are " << numberOfOpenDirections << " open squares around me\n";
    //if you have atleast 3(including the backwards direction) open directions you are at a fork
    if (numberOfOpenDirections >= 3)
    {
        return true;
    }

    return false;

}

//at a given fork this function tells if you are moving in the correct way using StudentWorld fucntion 
bool MovingActor::isValidForkDirection(int dir) {

    Board::GridEntry toRight, toUp, toLeft, toDown;
    getWorld()->boardThingNextToMe(getX(), getY(), toRight, toUp, toLeft, toDown);
   //check if its open direction in parameter
    if (dir == right) {
        if (toRight != Board::empty)
            return true;
    }
    else if (dir == left) {
        if (toLeft != Board::empty)
            return true;

    }
    else if (dir == up) {
        if (toUp != Board::empty)
            return true;

    }
    else if (dir == down) {
        if (toDown != Board::empty)
            return true;


    }
    return false;

}

//method to move avatar
void PlayerAvatar::doSomething() {
    StudentWorld* m_world = getWorld();
    //this returns what object the player is currently standing on 
    Actor* standingOn = m_world->isCollidingWith(getX(), getY());

    //if player is waiting to roll then
    if (isWaitingToRoll()) {

        //part a (invalid Direction)
        Board::GridEntry toRight, toLeft, toUp, toDown;
        m_world->boardThingNextToMe(getX(), getY(), toRight, toUp, toLeft, toDown);


        if (wasTeleported)
        {

            //if right is invalid and you are going right then chose radnom direction that is leagal 
            int newDir = getRandomDirection();
            if (newDir == left) {
                setDirection(left);
            }
            else
            {
                setDirection(right);
            }
            setDirectionOfWalk(newDir);

            wasTeleported = false;
        }

        int ticks = getTicksToMove();
        if (ticks != 0) { gotCoin = true; }
        //if (ticks_to_move != 0)

        //part B
       //if the player pressed tab/enter
        int r;
        switch (getWorld()->getAction(playerNum))  // cause hitting TAB to send ACTION_ROLL
        {

        case ACTION_ROLL:
            //roll the dice (1-10)

            r = (randInt(1, 10));
            //MAHI
           //r = 1;
            setRoll(r);

            //set the ticks to move
            setTicksToMove(r * 8);
             //let player know they can start walking by changing isWaiting to Roll
            setWaitingToRollState(false);

            break;

        //vortex commad
        case ACTION_FIRE:

            if (standingOn != nullptr && standingOn->canChangeDirection() && standingOn->getIsActive()) {
                int directionOfWalk = standingOn->getDirection();
                setDirectionOfWalk(directionOfWalk);
                if (directionOfWalk == left) { setDirection(left); }
                else setDirection(right);

            }
            if (!hasVortex)
                return;
            Vortex* newVortex;
            if (getDirectionOfWalk() == right) {
                newVortex = new Vortex(m_world, getX() + SPRITE_WIDTH, getY(), right);
                //    m_world->addActor(newVortex); 
            }
            else if (getDirectionOfWalk() == up) {
                newVortex = new Vortex(m_world, getX(), getY() + SPRITE_HEIGHT, up);
                //  m_world->addActor(newVortex);
            }
            else if (getDirectionOfWalk() == down) {
                newVortex = new Vortex(m_world, getX(), getY() - SPRITE_HEIGHT, down);
                //m_world->addActor(newVortex);
            }
            else if (getDirectionOfWalk() == left) {
                newVortex = new Vortex(m_world, getX() - SPRITE_WIDTH, getY(), left);

            }
            m_world->addActor(newVortex);
            hasVortex = false;
            break;
        default:
            // cerr << "Player " << playerNum << " ROLL PLEASE\n ";
            return;
            break;
        }
    }

    //moving and on a directional square actor  
    //a pg 29 
    else if (standingOn != nullptr && standingOn->canChangeDirection() && standingOn->getIsActive()) {
        int directionOfWalk = standingOn->getDirection();
        setDirectionOfWalk(directionOfWalk);
        if (directionOfWalk == left) { setDirection(left); }
        else setDirection(right);
        moveMe(directionOfWalk, true);
    }
    //b page 29 
    //moving and at a fork 
    else if (isAtFork() && !getIsAtStart()) {
        //cerr << getPlayerNum() << " IS AT FORK YEAH YEAH \n";
        int t = getWorld()->getAction(playerNum);

        switch (t)  // cause hitting TAB to send ACTION_ROLL
        {
            //cerr << "Player typed a " << t << endl;
        //check each direction 
        case ACTION_LEFT:
            if (getDirectionOfWalk() == right) {
                //cerr << "INVALID\n";
                return;
            }
            else if (isValidForkDirection(left)) {
                setDirectionOfWalk(left);
                setDirection(left);
                break;
            }
            //cerr << "INVALID DIRECTION CHOSEN\n";
            return;

            break;
        case ACTION_RIGHT:
            if (getDirectionOfWalk() == left) {
               // cerr << "INVALID\n";
                return;
            }
            if (isValidForkDirection(right)) {
                setDirectionOfWalk(right);
                setDirection(right);
                break;

            }
            //cerr << "INVALID DIRECTION CHOSEN\n";

            return;

            break;
        case ACTION_UP:
            if (getDirectionOfWalk() == down) {
             //   cerr << "INVALID\n";

                return;
            }
            if (isValidForkDirection(up)) {
                setDirectionOfWalk(up);
                setDirection(right);
                break;

            }
           // cerr << "INVALID DIRECTION CHOSEN\n";

            return;
            break;
        case ACTION_DOWN:
            if (getDirectionOfWalk() == up) {
              //  cerr << "INVALID\n";
                return;
            }
            if (isValidForkDirection(down)) {
                setDirectionOfWalk(down);
                setDirection(right);
                break;

            }
           //cerr << "INVALID DIRECTION CHOSEN\n";

            return;

            break;
        default:
           // cerr << "Choose a direction player " << playerNum << endl;

            return;
        }
        gotCoin = false;
        hasBeenAttacked = false;
        //after chosing valid direction move
        movePYB();
    }

    //else is in WALKING STATE and not on any directional square
    //c page 29 
    //if you are moving and at  a corner 
    else
    {
        setIsAtStart();
        gotCoin = false;
        hasBeenAttacked = false;

        movePYB();
       

    }
}


//constructor for coin square
CoinSquare::CoinSquare(StudentWorld* sw, int id, int x, int y, int amt) :
    Actor(sw, id, x, y, 1, 0)
{
    //this is used to differentiate betwwen red and blue coin squares (the amount is +/- 3)
    coin_amount = amt;
    isAlive = true;
    gaveCoin = false;
}
void CoinSquare::doSomething()
{
    //if the coin square is changed by Bowser return immediately 
    if (!getIsActive()) {
        setVisible(false);
        return;
    }
    else
    {
        StudentWorld* m_world = getWorld();
        //if a New player is Directly on top of a coinsquare then (isNewPlayer returns whether a new player is on top of the square)
        if ((m_world->isNewPlayer(getX(), getY())))
        {
            //if its a new player update coins and play sound
            m_world->updateCoins(coin_amount, getX(), getY());
            // gaveCoin = true;
            if (coin_amount < 0) {
                m_world->playSound(SOUND_TAKE_COIN);
                return;
            }
            else
                m_world->playSound(SOUND_GIVE_COIN);
            return;
        }
        else
        {
            //gaveCoin = false;
            return;
        }
    }
}

//Star Square constructor

StarSquare::StarSquare(StudentWorld* sw, int id, int x, int y)
    :Actor(sw, id, x, y, 1, 0)
{
    //initially we have not yet given a star to a player
    gaveStarToPlayer = false;
}

void StarSquare::doSomething() {

    if (!getIsActive()) {
        setVisible(false);
        return;
    }
    else
    {
        StudentWorld* m_world = getWorld();
        //if the player is walking and on top of me or standing on top of me then give me a coin 
        if ((m_world->isWalkingOnTopOf(getX(), getY()) || m_world->isNewPlayer(getX(), getY()))) {
            if (!gaveStarToPlayer) {
                //if the player has atleast 20 coins
                if (m_world->howManyCoins(getX(), getY()) >= 20)
                {
                    gaveStarToPlayer = true;
                    m_world->updateCoins(-20, getX(), getY());
                    //giveStar
                    m_world->playSound(SOUND_GIVE_STAR);
                }
                else
                    return;

            }
        }
        else
        {
            gaveStarToPlayer = false;
        }

    }
}
//constructor for directional square
DirectionalSquare::DirectionalSquare(StudentWorld* sw, int id, int x, int y, int directionOfImage)
    : Actor(sw, id, x, y, 1, directionOfImage)
{
    forcingDirection = directionOfImage;
}
void DirectionalSquare::doSomething() {
    //player checks if they are on top of this
    if (!getIsActive()) {
        setVisible(false);
        return;
    }
}


// constructor for bank square
BankSquare::BankSquare(StudentWorld* sw, int id, int x, int y)
    :Actor(sw, id, x, y, 1, 0)
{
    //check for going over vs on top of 
    playerAlreadyLostCoin = false;
}
void BankSquare::doSomething() {
    if (!getIsActive()) {
        setVisible(false);
        return;
    }
    StudentWorld* m_world = getWorld();
    if (m_world->isNewPlayer(getX(), getY())) {
        int amt = (m_world->getBankBalance());
        m_world->updateBank(-amt);
        m_world->updateCoins(amt, getX(), getY());
        m_world->playSound(SOUND_WITHDRAW_BANK);
        //set flag so it isnt occuring two times
        playerAlreadyLostCoin = true;
    }
    else if (m_world->isWalkingOnTopOf(getX(), getY()) && !playerAlreadyLostCoin) {
        //have player remember which bank square it got money from or other way around 
        //have a flag that is set to true if player is standing on or walking across and after it walks across then set it to false 
        if (!playerAlreadyLostCoin) {

            playerAlreadyLostCoin = true;
            int playersCoins = m_world->howManyCoins(getX(), getY());
            if (playersCoins < 5)
            {
                m_world->updateCoins(-playersCoins, getX(), getY());
                m_world->updateBank(playersCoins);
            }
            else
            {
                m_world->updateCoins(-5, getX(), getY());
                m_world->updateBank(5);
            }
            m_world->playSound(SOUND_DEPOSIT_BANK);
            //playerGotCoins = false;

        }

    }


}

EventSquare::EventSquare(StudentWorld* sw, int id, int x, int y)
    :Actor(sw, id, x, y, 1, 0)
{
}
void EventSquare::doSomething()
{
    if (!getIsActive()) {
        setVisible(false);
        return;
    }
    StudentWorld* m_world = getWorld();
    if (m_world->isNewPlayer(getX(), getY()))
    {
        //chode random 1-3
        int choice = randInt(1, 3);
        //MAHI
       // choice = 3;
        if (choice == 1)
        {
            cerr << "choice 1\n";
            m_world->movePlayerTo(getX(), getY());
            m_world->playSound(SOUND_PLAYER_TELEPORT);
        }
        else if (choice == 2)
        {
            cerr << "choice 2\n";
            m_world->swapPlayers();
            m_world->playSound(SOUND_PLAYER_TELEPORT);

        }
        else {
            m_world->giveVortexPower(getX(), getY());
            m_world->playSound(SOUND_GIVE_VORTEX);
        }

    }
}

DroppingSquare::DroppingSquare(StudentWorld* sw, int bowserX, int bowserY)
    :Actor(sw, IID_DROPPING_SQUARE, bowserX, bowserY, 1, 0)
{
    
}
void DroppingSquare::doSomething() {

    StudentWorld* m_world = getWorld();
    Actor* replacement = m_world->isCollidingWith(getX(), getY());
    //if is active chane to inactive
        if (replacement != nullptr && replacement->is_a_square() && !(replacement->impactsOthers()) && replacement->getIsActive())
    {
        //set to invisible 
        m_world->setInactive(getX(), getY());
    }
    //finding out 
    if (m_world->isNewPlayer(getX(), getY())) {
        int choice = randInt(1, 2);
        if (choice == 1) {
            m_world->updateCoins(-10, getX(), getY());
        }
        else
        {
            m_world->updateStars(-1, getX(), getY());
        }
        m_world->playSound(SOUND_DROPPING_SQUARE_ACTIVATE);
    }

}


//base class for boo and baddies
Baddie::Baddie(StudentWorld* sw, int id, int x, int y) :MovingActor(sw, id, x, y, 0, 0) {
    travelDistance = 0;
    setWaitingToRollState(true);
    pauseCounter = 180;
    squares_to_move = 0;
    setTicksToMove(0);
    ticks_to_move = 0;
}
//chose a radnom direction 
int MovingActor::getRandomDirection() {
    Board::GridEntry toRight, toLeft, toUp, toDown;
    m_world->boardThingNextToMe(getX(), getY(), toRight, toUp, toLeft, toDown);
    int newDir = randInt(0, 3);
    newDir *= 90;
    if (newDir == right)
    {
        if (toRight != Board::empty)
        {
            return newDir;
            //canGoInThisDirection = true;
        }
    }
    else if (newDir == up) {
        if (toUp != Board::empty) {
            return newDir;
            //canGoInThisDirection = true;
        }
    }
    else if (newDir == down) {
        if (toDown != Board::empty) {
            return newDir;
            // canGoInThisDirection = true;
        }
    }
    else if (newDir == left) {
        if (toLeft != Board::empty) {
            return newDir;
            // canGoInThisDirection = true;
        }
    }
    //until a valid direction keep recursing
    return getRandomDirection();
}


void Baddie::doSomething(int steps) {
    //this is base class or is part a of baddie on spec 
    //StudentWorld* m_world = getWorld();

    pauseCounter--;
    if (pauseCounter <= 0) {
        squares_to_move = (randInt(1, steps));
        setTicksToMove(squares_to_move * 8);
        //call functiocn
        int newDir = getRandomDirection();
        if (newDir == left) {
            setDirection(left);
        }
        else
        {
            setDirection(right);
        }
        setDirectionOfWalk(newDir);
        // setMovingState(false);
         // setPauseCounter();
        setWaitingToRollState(false);
    }



}

Bowser::Bowser(StudentWorld* sw, int id, int x, int y) :Baddie(sw, id, x, y) {
    //flag to only attack once
    haveAttacked = false;
}
void Bowser::doSomething() {
    StudentWorld* m_world = getWorld();

    if (isWaitingToRoll()) {

        if (m_world->isNewPlayer(getX(), getY(), true) && !haveAttacked)
        {
            int choice = randInt(1, 2);   
            if (choice == 1) {
                //delete coins/ everything 
               // cerr << "OOPS BOSWER STOLE YOUR COINS\n";
                m_world->removeCoins(getX(), getY());
                m_world->updateAttack(getX(), getY());

                haveAttacked = true;
                m_world->playSound(SOUND_BOWSER_ACTIVATE);

            }


        }
        //call base class method (OOP)
        Baddie::doSomething(10);

    }
    else {
        //check if at fork 
        if (isAtFork())
        {
            int newDir = getRandomDirection();
            if (isValidForkDirection(newDir))
            {
                if (newDir == left)
                {
                    setDirection(left);
                }
                else
                {
                    setDirection(right);
                }
                setDirectionOfWalk(newDir);
            }
            else {
                return;
            }
        }

        movePYB();
        haveAttacked = false;
        if (getTicksToMove() <= 0) {
            setPauseCounter();
            int r = randInt(1, 4);
            
            if (r == 1) {
                DroppingSquare* dropDSqaure = new DroppingSquare(m_world, getX(), getY());
                m_world->addActor(dropDSqaure);
                m_world->playSound(SOUND_DROPPING_SQUARE_CREATED);


            }
        }

    }
}

//Boo class contructor 
Boo::Boo(StudentWorld* sw, int id, int x, int y)
    :Baddie(sw, id, x, y) {
    //flag 
    haveAttacked = false;


}
void Boo::doSomething() {
    //call parent classes doSomething later 
    StudentWorld* m_world = getWorld();

    if (isWaitingToRoll()) {

        if (m_world->isNewPlayer(getX(), getY(), true) && !haveAttacked)
        {
            int choice = randInt(1, 2);
           
            if (choice == 1) {
                //swap
                cerr << "Swapping COINS\n";
                m_world->swapPlayerCoins();
                m_world->updateAttack(getX(), getY());
                haveAttacked = true;
            }
            else
            {
                cerr << "Swapping STARS\n";
                m_world->swapPlayerStars();
                m_world->updateAttack(getX(), getY());
                haveAttacked = true;
            }
            m_world->playSound(SOUND_BOO_ACTIVATE);
            haveAttacked = true;
        }
        //base class stuff for repeated code 
        Baddie::doSomething();

    }
    //they are in walking/unPaused state
    else {
        if (isAtFork())
        {
            int newDir = getRandomDirection();
            if (isValidForkDirection(newDir))
            {
                if (newDir == left)
                {
                    setDirection(left);
                }
                else
                {
                    setDirection(right);
                }
                setDirectionOfWalk(newDir);
            }
            else {
                return;
            }
        }
        movePYB();
        haveAttacked = false;
        if (getTicksToMove() <= 0) {
            setPauseCounter();
        }

    }

}


//Vortex methods 
Vortex::Vortex(StudentWorld* sw, int x, int y, int moveDirection) :
    MovingActor(sw, IID_VORTEX, x, y, 0, 0)
{
    setDirectionOfWalk(moveDirection);

}
void Vortex::doSomething() {

    if (!getIsActive()) {
        setVisible(false);
        return;
    }
    if (getX() > VIEW_WIDTH || getY() > VIEW_HEIGHT || getX() < 0 || getY() < 0) {
        setIsActive(false);
        return;
    }
    moveAtAngle(getDirectionOfWalk(), 2);
    Actor* crashedWith = getWorld()->vortexOverLapsWith(getX(), getY());

    if (crashedWith != nullptr) {
        getWorld()->playSound(SOUND_HIT_BY_VORTEX);
       // setIsActive(false); 
        crashedWith->hit_by_vortex();
        
        setIsActive(false);
        cerr << "BOOOM\n";
    }


}

//move player/baddies to random square
void MovingActor::moveToRandomSquare() {
    int newX = getX(), newY = getY();
    int x, y;
    //Board::GridEntry myBox;
    Actor* onSquare;

    while (true) {
        x = randInt(0, VIEW_WIDTH);
        y = randInt(0, VIEW_HEIGHT);
        if (x % 16 != 0 && y % 16 != 0) {
            continue;
        }
        onSquare = getWorld()->isCollidingWith(x, y);

        if (onSquare != nullptr)
        {
            newX = onSquare->getX();
            newY = onSquare->getY();
            break;
        }
    }
    //moves player respectivly 
    moveMeToLoc(newX, newY);
}