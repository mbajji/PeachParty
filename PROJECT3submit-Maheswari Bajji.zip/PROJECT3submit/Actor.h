#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"




class Actor :public GraphObject
{
public:
    Actor(StudentWorld* sw, int image_id, int x, int y, int depth, int direction = 0);
   virtual ~Actor() {};
    virtual void doSomething() = 0;
    virtual bool getIsActive() { return isActive; };
    virtual  void setIsActive(bool b) { isActive = b; }
    virtual bool isImpactable() { return false; }
    StudentWorld* getWorld() { return m_world; }
    virtual bool canChangeDirection() { return false; }
    virtual bool is_a_square() const = 0;
    virtual void hit_by_vortex() {
        hit_by_vortex();
    };  // tell an game object it has been hit by a vortex
    virtual bool impactsOthers() { return false; }

   // virtual StudentWorld* getWorld();
private:
    bool isActive = true;
    StudentWorld* m_world;
};



class MovingActor : public Actor {
public:
    MovingActor(StudentWorld* sw, int image_id, int x, int y, int depth, int direction = 0);
    virtual ~MovingActor() {}; 
    virtual void doSomething() = 0;
    //StudentWorld* getWorld();
    virtual bool changesCoins() { return false; }
    void movePYB();
    bool isWaitingToRoll() { return isInWaitingToRollState; };
    void setWaitingToRollState(bool state) { isInWaitingToRollState = state; }
    int getRoll() { return die_roll; }
    void setRoll(int roll) { die_roll = roll; }
    int getTicksToMove() { return ticks_to_move; }
    void setTicksToMove(int val) { ticks_to_move = val; }
    int getDirectionOfWalk() { return directionOfWalk; }
    void setDirectionOfWalk(int dir) { directionOfWalk = dir; }
    virtual bool is_a_square() const = 0;
    // bool getIsActive() { return isActive; }
   //  void setIsActive(bool b) { isActive = b; }
    bool getIsAtStart() { return isAtStart; }
    void setIsAtStart() { isAtStart = false; }
    bool isAtFork();
    bool isValidForkDirection(int dir);
    int getRandomDirection();
    // virtual bool isImpactable() { return false; }
    void moveToRandomSquare();
    virtual void moveMeToLoc(int x, int y) { moveTo(x, y); };
    virtual void setPauseCounter() { isInWaitingToRollState = true; }
    virtual void hit_by_vortex() {}

    
protected:
    void moveMe(int direction, bool canChangeDieRoll);

private:
    bool isActive;
    StudentWorld* m_world;
    int directionOfWalk = right;
    bool isInWaitingToRollState = true;
    int die_roll = 0;
    int ticks_to_move = 0;
    bool isAtStart = true;

};
class PlayerAvatar :public MovingActor
{
public:
    PlayerAvatar(StudentWorld* sw, int id, int x, int y, int whichPlayer);
    virtual void doSomething();
    //bool isWaitingToRoll() { return isInWaitingToRollState; };
    //int getRoll() { return die_roll; }
    virtual ~PlayerAvatar() { }
    void addCoins(int amt) { if (!gotCoin) coins += amt; if (coins <= 0) coins = 0; }
    void updategotCoin(bool b = true) { gotCoin = b; }
    bool getGCoin() { return gotCoin; }
    int coinAmount() { return coins; }
    void giveStar(int amt = 1) { stars += amt; if (stars <= 0) stars = 0; }
    int getStar() { return stars; }
    int getPlayerNum() { return playerNum; }
    void resetCoins() { coins = 0; }
    void resetStars() { stars = 0; }
    virtual void moveMeToLoc(int x, int y)
    {
        moveTo(x, y);
        gotCoin = false;
        wasTeleported = true;

    };
    virtual bool is_a_square() const { return false; }
    bool playerHasBeenAttacked() { return hasBeenAttacked; };

    void setPlayerHasBeenAttacked(bool b) { hasBeenAttacked = b; };

    void swapMeWith(PlayerAvatar* other);
    void updateTeleport(bool b) { wasTeleported = b; };
    void setHasVortex() { if (!hasVortex) hasVortex = true; }
    bool getHasVortex() { return hasVortex; }
    //bool isAtFork(); 
    //bool newPlayer() { return isNewCoin; }
    //void moveToRandomSquare(); 


private:
    // bool isInWaitingToRollState;
    int playerNum;
    //int ticks_to_move;
   // int directionOfWalk;

 //   int die_roll;
    //void moveMe(int direction, bool canChangeDieRoll);
    bool gotCoin;
    int coins;
    bool canGetStar;
    int stars;
    bool hasBeenAttacked;
    bool wasTeleported = false;
    bool hasVortex = false;

};


class CoinSquare : public Actor {
public:
    CoinSquare(StudentWorld* sw, int id, int x, int y, int amt);
    virtual ~CoinSquare() {  };
    virtual void doSomething();
    // virtual bool changesCoins() { return true; };
    virtual bool is_a_square() const { return true; }
    virtual void hit_by_vortex() {}

private:
    int coin_amount;
    bool isAlive;
    bool gaveCoin;
};

class StarSquare : public Actor {
public:
    StarSquare(StudentWorld* sw, int id, int x, int y);
    virtual ~StarSquare() { };
    virtual void doSomething();
    virtual bool is_a_square() const { return true; }

private:
    bool gaveStarToPlayer;
};

class DirectionalSquare :public Actor {
public:
    DirectionalSquare(StudentWorld* sw, int id, int x, int y, int directionOfImage);
    virtual ~DirectionalSquare() { };
    virtual void doSomething();
    virtual bool canChangeDirection() { return true; }
    int getForcingDirection() { return forcingDirection; }
    virtual bool is_a_square() const { return true; }
    virtual void hit_by_vortex() {}

private:
    int forcingDirection;
};

class BankSquare : public Actor
{
public:
    BankSquare(StudentWorld* sw, int id, int x, int y);
    virtual ~BankSquare() {};
    virtual void doSomething();
    virtual bool is_a_square() const { return true; }
    virtual void hit_by_vortex() {}

private:
    bool playerAlreadyLostCoin;
    bool playerGotCoins = false;
};

class EventSquare :public Actor
{
public:
    EventSquare(StudentWorld* sw, int id, int x, int y);
    virtual ~EventSquare() { };
    virtual void doSomething();
    virtual bool is_a_square() const { return true; }
    virtual void hit_by_vortex() {}

private:

};

class DroppingSquare :public Actor {
public:
    DroppingSquare(StudentWorld* sw, int bowserX, int bowserY);
    virtual ~DroppingSquare() {  };
    virtual void doSomething();
    virtual bool is_a_square() const { return true; }
    virtual void hit_by_vortex() {}

private:

};


class Baddie :public MovingActor {
public:
    Baddie(StudentWorld* sw, int id, int x, int y);
    virtual ~Baddie() {  };
    virtual void doSomething(int steps = 3);
    //bool getIsPaused() { return isPaused; }
    void setPauseCounter() { pauseCounter = 180; }
    virtual bool is_a_square() const { return false; }
    virtual bool isImpactable() { return true; }
    void hit_by_vortex() {
        moveToRandomSquare();
        setDirection(right);
        setDirectionOfWalk(right);
        setWaitingToRollState(true);
        setPauseCounter();
    }

private:
    int travelDistance;
    //bool isPaused; 
    int pauseCounter;
    int squares_to_move;
    int ticks_to_move;
};

class Bowser :public Baddie {
public:
    Bowser(StudentWorld* sw, int id, int x, int y);
    virtual ~Bowser() {}
    virtual void doSomething();
    virtual bool is_a_square() const { return false; }
private:
    bool haveAttacked;
};
class Boo :public Baddie {
public:
    Boo(StudentWorld* sw, int id, int x, int y);
    virtual ~Boo() {  }
    virtual void doSomething();
private:
    bool haveAttacked;
};


class Vortex : public MovingActor {
public:
    Vortex(StudentWorld* sw, int x, int y, int walkDirection);
    virtual void doSomething();
    virtual ~Vortex() { };
    
    virtual bool is_a_square() const { return false; }
    virtual bool impactsOthers() { return true; }
};
#endif // ACTOR_H_