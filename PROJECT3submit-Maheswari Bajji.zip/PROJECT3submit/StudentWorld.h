#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_


#include "GameWorld.h"
#include "Board.h"
#include <string>
#include <vector>
class PlayerAvatar;
//#include "Actor.h"
class MovingActor;
class Actor;
using namespace std;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetPath);
	~StudentWorld();
	virtual int init();
	virtual int move();
	virtual void cleanUp();
	//this function returns what the contents of the board are for a given x and y
	void boardThingNextToMe(int currentX, int currentY, Board::GridEntry& toRight, Board::GridEntry& toUp, Board::GridEntry& toLeft, Board::GridEntry& toDown);
	Actor* isCollidingWith(int x, int y);
	bool isNewPlayer(int x, int y, bool b = false);
	void updateCoins(int amt, int x, int y);
	void updateStars(int amt, int x, int y);

	int howManyCoins(int x, int y);
	int howManyStars(int x, int y);
	void swapPlayerCoins();
	void swapPlayerStars();
	//bool isNewUnnatackedPlayer(int x, int y);
	void updateAttack(int x, int y);
	void movePlayerTo(int currentX, int currentY);

	void swapPlayers();

	bool isWalkingOnTopOf(int x, int y);
	void updateBank(int amt) { bankBalance += amt; if (bankBalance <= 0) { bankBalance = 0; } }
	int getBankBalance() { return bankBalance; }

	void removeCoins(int x, int y);
	void addActor(Actor* newActorPointer) {
		actors.push_back(newActorPointer);
	}
	void giveVortexPower(int x, int y);
	void setInactive(int x, int y);

	//void updateBaddiedPauseCounter(int x, int y); 


	Actor* vortexOverLapsWith(int x, int y);
private:

	PlayerAvatar* m_Peach;
	PlayerAvatar* m_Yoshi;
	vector<Actor*> actors;
	Board m_Board;
	int bankBalance;
	bool hasBowser;
};

#endif // STUDENTWORLD_H_