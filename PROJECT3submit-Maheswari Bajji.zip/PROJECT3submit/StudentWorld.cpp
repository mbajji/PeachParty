#include "StudentWorld.h"
#include "Actor.h"
#include "Board.h"
#include "GameConstants.h"
#include <string>
#include <vector>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}
//constructor for creating a world 
StudentWorld::StudentWorld(string assetPath)
	: GameWorld(assetPath)
{
	m_Peach = nullptr;
	m_Yoshi = nullptr;

	actors.clear();
	bankBalance = 0;
	hasBowser = false;
}
StudentWorld::~StudentWorld() { }

//init function to initialize all actors 
int StudentWorld::init()
{
	bankBalance = 0;
	string boardNum = "0" + to_string(getBoardNumber());
	//load correct board based on what was typed in 
	string boardFile = "board" + boardNum + ".txt";
	string board_file = assetPath() + boardFile;
	Board::LoadResult result = m_Board.loadBoard(board_file);

	if (result == Board::load_fail_file_not_found) {
		cerr << "Could not find board data file\n";
		return GWSTATUS_BOARD_ERROR;
	}

	else if (result == Board::load_fail_bad_format)
	{
		cerr << "Your board was improperly formatted\n";
		return GWSTATUS_BOARD_ERROR;
	}

	else if (result == Board::load_success) {
		cerr << "Successfully loaded board\n";
		//loop through board's txt file and create objects 
		for (int row = 0; row < VIEW_HEIGHT; row++) {
			for (int col = 0; col < VIEW_WIDTH; col++) {
				Board::GridEntry ge = m_Board.getContentsOf(row, col);
				switch (ge) {
				case Board::empty:
					break;
					//if @ then put player and blue square 
				case Board::player:
					actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 3));
					m_Peach = new PlayerAvatar(this, IID_PEACH, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 1);
					m_Yoshi = new PlayerAvatar(this, IID_YOSHI, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 2);
					break;
					//if its blue then add a coin square 
				case Board::blue_coin_square:
					actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 3));
					break;
				case Board::up_dir_square:
					actors.push_back(new DirectionalSquare(this, IID_DIR_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 90));
					break;
				case Board::down_dir_square:
					actors.push_back(new DirectionalSquare(this, IID_DIR_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 270));
					break;
				case Board::left_dir_square:
					actors.push_back(new DirectionalSquare(this, IID_DIR_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 180));
					break;
				case Board::right_dir_square:
					actors.push_back(new DirectionalSquare(this, IID_DIR_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 0));
					break;
				case Board::event_square:
					actors.push_back(new EventSquare(this, IID_EVENT_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col));
					break;
				case Board::bank_square:
					actors.push_back(new BankSquare(this, IID_BANK_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col));
					break;
				case Board::star_square:
					actors.push_back(new StarSquare(this, IID_STAR_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col));
					break;
				case Board::red_coin_square:
					actors.push_back(new CoinSquare(this, IID_RED_COIN_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, -3));
					break;
				case Board::boo:
					actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 3));
					actors.push_back(new Boo(this, IID_BOO, SPRITE_WIDTH * row, SPRITE_HEIGHT * col));
					break;
				case Board::bowser:
					if (!(hasBowser))
					{
						actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * row, SPRITE_HEIGHT * col, 3));
						actors.push_back(new Bowser(this, IID_BOWSER, SPRITE_WIDTH * row, SPRITE_HEIGHT * col));
						hasBowser = true;
					}
					break;
				}
			}
		}



	}
	//set a 99 sec timer
	startCountdownTimer(99);
	return GWSTATUS_CONTINUE_GAME;
}

//move all items by calling do something 
int StudentWorld::move()
{
	//print the required values to screen 
	string s;
	s = "P1 Roll: " + to_string(m_Peach->getRoll()) + " Stars: " + to_string(m_Peach->getStar()) + " $$: " + to_string(m_Peach->coinAmount());
	//if Peach has vortex change string 
	if (m_Peach->getHasVortex()) {
		s += " VOR";
	}
	//add more string 
	s += " | Time: " + to_string(timeRemaining()) + " | Bank: " + to_string(bankBalance) + " | P2 Roll: " + to_string(m_Yoshi->getRoll()) + " Stars: " + to_string(m_Yoshi->getStar()) + " $$: " + to_string(m_Yoshi->coinAmount());
	if (m_Yoshi->getHasVortex()) {
		s += " VOR";
	}

	setGameStatText(s);
	//call each players doSomething 
	m_Peach->doSomething();
	m_Yoshi->doSomething();

	//loop trhough vector and call doSomething
	for (unsigned int i = 0; i < (actors.size()); i++) {
		if (actors[i] != nullptr)
		{
			actors[i]->doSomething();
		}
		
	}
	if (timeRemaining() <= 0)
	{
		playSound(SOUND_GAME_FINISHED);
		//check for winner
		int pCoin = m_Peach->coinAmount();
		int pStars = m_Peach->getStar();

		int yCoin = m_Yoshi->coinAmount();
		int yStars = m_Yoshi->getStar();

		if (pStars > yStars) {
			setFinalScore(pStars, pCoin);
			return GWSTATUS_PEACH_WON;

		}
		if (yStars > pStars) {
			setFinalScore(yStars, yCoin);
			return GWSTATUS_YOSHI_WON;

		}
		if (pCoin > yCoin) {
			setFinalScore(pStars, pCoin);
			return GWSTATUS_PEACH_WON;


		}
		if (yCoin > pCoin) {
			setFinalScore(yStars, yCoin);
			return GWSTATUS_YOSHI_WON;

		}
		int randomWinner = randInt(1, 2);
		if (randomWinner == 1)
		{
			setFinalScore(pStars, pCoin);
			return GWSTATUS_PEACH_WON;
		}
		setFinalScore(yStars, yCoin);
		return GWSTATUS_YOSHI_WON;

	}
	//deleting dead/inactive 
	for (unsigned int i = 0; i < (actors.size()); i++) {
		if (actors[i] != nullptr) {
			bool b = actors[i]->getIsActive(); 
			if (!b)
			{
				if (actors[i]->impactsOthers())
				{
					delete actors[i];
					actors[i] = nullptr;
				}
			}
		}
		
	}
	return GWSTATUS_CONTINUE_GAME;
}

//function returns to the caller what is surrounding the player in all 4 sides using the board's array 
void StudentWorld::boardThingNextToMe(int currentX, int currentY, Board::GridEntry& toRight, Board::GridEntry& toUp, Board::GridEntry& toLeft, Board::GridEntry& toDown)
{
	//SPRITE_WIDTH
	toRight = m_Board.getContentsOf((currentX + SPRITE_WIDTH) / SPRITE_WIDTH, currentY / SPRITE_HEIGHT);
	toUp = m_Board.getContentsOf(currentX / SPRITE_WIDTH, (currentY + SPRITE_HEIGHT) / SPRITE_HEIGHT);
	toLeft = m_Board.getContentsOf(((currentX)-SPRITE_WIDTH) / SPRITE_WIDTH, currentY / SPRITE_HEIGHT);
	toDown = m_Board.getContentsOf((currentX) / SPRITE_WIDTH, ((currentY)-SPRITE_HEIGHT) / SPRITE_HEIGHT);

}
//cleans Up all actors at end (same as the destructor) 
void StudentWorld::cleanUp()
{
	cerr << "In cleanup\n";
	delete m_Peach;
	m_Peach = nullptr;

	delete m_Yoshi;
	m_Yoshi = nullptr;
	int n = actors.size();
	for (int i = 0; i < n; i++) {
		delete (actors[i]);
	}
	actors.clear();
}

//function returns what actor player is standing on top of /walking on 
Actor* StudentWorld::isCollidingWith(int x, int y) {
	for (unsigned int i = 0; i < actors.size(); i++) {
		if (actors[i] != nullptr) {

		
			if ((actors[i]->getX() == x) && (actors[i]->getY() == y)) {
				return actors[i];
			}
		}
	}
	return nullptr;
}

//sets things to inactive so they can deleted accurately 
void StudentWorld::setInactive(int x, int y) {
	for (unsigned int i = 0; i < actors.size(); i++) {
		if (actors[i] != nullptr)
		{
			if ((actors[i]->getX() == x) && (actors[i]->getY() == y)) {
				actors[i]->setIsActive(false);
			}
		}
	}
}
//returns to coin square if a new actor stood on it 
bool StudentWorld::isNewPlayer(int x, int y, bool baddieCalledMe)
{
	//this code is called by an attacker
	if (baddieCalledMe)
	{
		if (m_Peach->isWaitingToRoll() && !(m_Peach->playerHasBeenAttacked())) {
			if (m_Peach->getX() == x && m_Peach->getY() == y) {
				//m_Peach->setPlayerHasBeenAttacked(true);
				return true;
			}
		}
		if (m_Yoshi->isWaitingToRoll() && !(m_Yoshi->playerHasBeenAttacked())) {
			if (m_Yoshi->getX() == x && m_Yoshi->getY() == y) {
				//m_Peach->setPlayerHasBeenAttacked(true);
				return true;
			}
		}
		return false;
	}

	//this code runs from a square
	//if (x % 16 != 0 || y % 16 != 0) return false; 
	if (m_Peach->isWaitingToRoll() && !(m_Peach->getGCoin())) {
		if (m_Peach->getX() == x && m_Peach->getY() == y) {

			return true;
		}
	}
	if (m_Yoshi->isWaitingToRoll() && !(m_Yoshi->getGCoin())) {
		if (m_Yoshi->getX() == x && m_Yoshi->getY() == y) {
			return true;
		}
	}
	return false;
}

//updates that the player is NO longer new
void StudentWorld::updateAttack(int x, int y) {
	if ((m_Peach->getX() == x) && (m_Peach->getY()) == y && !(m_Peach->playerHasBeenAttacked())) {
		m_Peach->setPlayerHasBeenAttacked(true);

	}
	if ((m_Yoshi->getX() == x) && (m_Yoshi->getY()) == y && !(m_Yoshi->getGCoin())) {
		m_Yoshi->setPlayerHasBeenAttacked(true);
	}
}


//updates the coin the player  have
void StudentWorld::updateCoins(int amt, int x, int y)
{

	if ((m_Peach->getX() == x) && (m_Peach->getY()) == y && !(m_Peach->getGCoin())) {
		m_Peach->addCoins(amt);
		m_Peach->updategotCoin();
		if (amt == -20) {
			m_Peach->giveStar();
		}
	}
	if ((m_Yoshi->getX() == x) && (m_Yoshi->getY()) == y && !(m_Yoshi->getGCoin())) {
		m_Yoshi->addCoins(amt);
		m_Yoshi->updategotCoin();
		if (amt == -20) {
			m_Yoshi->giveStar();
		}
	}


}

//changes stars the player has
void StudentWorld::updateStars(int amt, int x, int y) {
	if ((m_Peach->getX() == x) && (m_Peach->getY()) == y) {
		m_Peach->giveStar(amt);
	}
	if ((m_Yoshi->getX() == x) && (m_Yoshi->getY()) == y) {
		m_Yoshi->giveStar(amt);
	}
}

//removes all coins from player 
void StudentWorld::removeCoins(int x, int y) {
	if ((m_Peach->getX() == x) && (m_Peach->getY()) == y) {
		m_Peach->resetCoins();
		return;
	}
	if ((m_Yoshi->getX() == x) && (m_Yoshi->getY()) == y) {
		m_Yoshi->resetCoins();
		return;
	}

}

//returns how many coins the player has  - used by baddies 
int StudentWorld::howManyCoins(int x, int y) {

	if (m_Peach->getX() == x && m_Peach->getY() == y)
	{
		return m_Peach->coinAmount();
	}
	if (m_Yoshi->getX() == x && m_Yoshi->getY() == y)
	{
		return m_Yoshi->coinAmount();
	}
	return 0;
}

//returns how many stars the player has -  used by baddies 
int StudentWorld::howManyStars(int x, int y) {

	if (m_Peach->getX() == x && m_Peach->getY() == y)
	{
		return m_Peach->getStar();
	}
	if (m_Yoshi->getX() == x && m_Yoshi->getY() == y)
	{
		return m_Yoshi->getStar();
	}
	return 0;
}

//returns whether the players are walking (used in star class/bank)
bool StudentWorld::isWalkingOnTopOf(int x, int y) {
	if (x % 16 == 0 && y % 16 == 0)
	{
		if (!m_Peach->isWaitingToRoll()) {
			if (m_Peach->getX() == x && m_Peach->getY() == y)
			{
				return true;
			}
		}
		if (!m_Yoshi->isWaitingToRoll()) {
			if (m_Yoshi->getX() == x && m_Yoshi->getY() == y)
			{
				return true;
			}
		}
	}
	return false;
}

//swaps the coins
void StudentWorld::swapPlayerCoins() {
	int pCoins = m_Peach->coinAmount();
	int yCoins = m_Yoshi->coinAmount();
	m_Peach->updategotCoin(false);
	m_Yoshi->updategotCoin(false);

	m_Peach->resetCoins();
	m_Yoshi->resetCoins();
	m_Peach->addCoins(yCoins);
	m_Yoshi->addCoins(pCoins);
	m_Peach->updategotCoin();
	m_Yoshi->updategotCoin();
}

//swaps the stars
void StudentWorld::swapPlayerStars() {
	int pStar = m_Peach->getStar();
	int yStar = m_Yoshi->getStar();
	//intiially reststs stars to 0 
	m_Peach->resetStars();
	m_Yoshi->resetStars();
	for (int i = 0; i < yStar; i++) {
		m_Peach->giveStar();
	}
	for (int i = 0; i < pStar; i++) {
		m_Yoshi->giveStar();
	}

}

//moves player randomly 
void StudentWorld::movePlayerTo(int currentX, int currentY) {


	if (m_Peach->getX() == currentX && m_Peach->getY() == currentY) {
		m_Peach->moveToRandomSquare();
		//cerr << "Peachcan totally change now\n";
		//m_Peach->moveMeToLoc(newX, newY); 
	}
	else
	{
		m_Yoshi->moveToRandomSquare();
		cerr << "Yoshi totally change now\n";
		//m_Yoshi->moveMeToLoc(newX, newY);
	}
}

//swaps player used by baddies  
void StudentWorld::swapPlayers() {
	//Peaches values all

	m_Yoshi->swapMeWith(m_Peach);
	m_Yoshi->updategotCoin();
	m_Peach->updategotCoin();

}



//lets player know they have a new vortex
void StudentWorld::giveVortexPower(int x, int y) {
	if (m_Peach->getX() == x && m_Peach->getY() == y)
	{
		m_Peach->setHasVortex();
		m_Peach->updategotCoin();
	}
	else
	{
		m_Yoshi->setHasVortex();
		m_Yoshi->updategotCoin();
	}
}

//checks where they overlap(vortex)
Actor* StudentWorld::vortexOverLapsWith(int x, int y) {
	for (unsigned int i = 0; i < actors.size(); i++) {
		if (actors[i]!=nullptr)
		{
			if (actors[i]->isImpactable()) {
				int currentX = actors[i]->getX(), currentY = actors[i]->getY();


				
				int lowestX = x - 16, highestX = x + 16;
				int lowestY = y - 16, highestY = y + 16;

				if (currentX >= lowestX && currentX <= highestX && currentY >= lowestY && currentY <= highestY) {
					return actors[i];
				}
			}
		}
		
	}
	return nullptr;
}